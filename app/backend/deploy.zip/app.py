import os
import logging
import openai
from flask import Flask, request, jsonify
from azure.identity import DefaultAzureCredential
from approaches.chatreadretrieveread import ChatReadRetrieveReadApproach
from dotenv import load_dotenv
import sys
import requests
import json
import logging
import time

env_path = os.path.join(os.path.dirname(__file__), '.env')
load_dotenv(env_path, verbose=True, override=True)

# Replace these with your own values, either in environment variables or directly here
AZURE_OPENAI_SERVICE = os.environ.get("AZURE_OPENAI_SERVICE") or "myopenai"
AZURE_OPENAI_GPT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_GPT_DEPLOYMENT") or "davinci"
AZURE_OPENAI_CHATGPT_DEPLOYMENT = os.environ.get("AZURE_OPENAI_CHATGPT_DEPLOYMENT") or "chat"

# Used by the OpenAI SDK
""" openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}.openai.azure.com"
openai.api_version = "2023-03-15-preview"
openai.api_key = os.getenv("OPENAI_API_KEY") """

openai.api_type = "azure"
openai.api_base = f"https://{AZURE_OPENAI_SERVICE}"
openai.api_version = "2023-03-15-preview"
openai.api_key = os.getenv("OPENAI_API_KEY")


test_api_url = openai.api_base

##
##    function to obtain a new OAuth 2.0 token from the authentication server
##
def get_new_token():

    auth_server_url = "https://login.microsoftonline.com/organizations/oauth2/v2.0/token"
    client_id = 'dcd47f2d-bda3-46b9-bd90-70718944e9b3'
    client_secret = 'YCF8Q~sTpIJrdXUF3XSpm5PihFJHhlV0d51_Ja-f'

    token_req_payload = {'grant_type': 'client_credentials'}

    token_response = requests.post(auth_server_url,
    data=token_req_payload, verify=False, allow_redirects=False,
    auth=(client_id, client_secret))

    if token_response.status_code !=200:
        print("Failed to obtain token from the OAuth 2.0 server", file=sys.stderr)
        sys.exit(1)

    print("Successfuly obtained a new token")
    tokens = json.loads(token_response.text)
    return tokens['access_token']

token = get_new_token()

api_call_headers = {'Authorization': 'Bearer ' + token}
api_call_response = requests.get(test_api_url, headers=api_call_headers, verify=False)

if	api_call_response.status_code == 401:
    token = get_new_token()
else:
    print(api_call_response.text)
time.sleep(30)


chat_approaches = {
    "rrr": ChatReadRetrieveReadApproach(AZURE_OPENAI_CHATGPT_DEPLOYMENT, AZURE_OPENAI_GPT_DEPLOYMENT)
}

app = Flask(__name__)

@app.route("/", defaults={"path": "index.html"})
@app.route("/<path:path>")
def static_file(path):
    print(path)
    return app.send_static_file(path)

@app.route("/chat", methods=["POST"])
def chat():

    # ensure_openai_token()
    approach = request.json["approach"]
    try:
        impl = chat_approaches.get(approach)
        if not impl:
            return jsonify({"error": "unknown approach"}), 400
        r = impl.run(request.json["history"], request.json.get("overrides") or {}, request.json.get("sessionConfig") or {}, request.json.get("userInfo") or {}, dict(request.headers) or {})
        return jsonify(r)

    except Exception as e:
        logging.exception("Exception in /chat")
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run()
